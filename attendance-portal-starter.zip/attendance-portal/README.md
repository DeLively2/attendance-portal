# Attendly Attendance Portal

React + Vite frontend, Express backend, PostgreSQL, JWT auth, student/teacher/admin dashboards.

## Run
1. Create PostgreSQL database `attendance_portal`.
2. `cd server && cp .env.example .env && npm install && npm run dev`
3. In another terminal: `cd client && npm install && npm run dev`

Demo accounts:
- admin@example.com / Admin123!
- teacher@example.com / Teacher123!
- student@example.com / Student123!

Change demo passwords before production.
